# Contributing to pandas_redshift
- Reporting a bug
- Submitting a fix
- Proposing new features

## How to contribute
1. Fork the repo and create your branch from `master`.
2. Make changes to the new branch.
3. Issue a pull request (please include a summary).

## Contributions will be under the MIT Software License
[MIT License](http://choosealicense.com/licenses/mit/)
